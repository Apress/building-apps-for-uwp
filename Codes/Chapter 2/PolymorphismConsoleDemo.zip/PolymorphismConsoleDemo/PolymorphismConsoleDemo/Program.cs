﻿using System;

namespace PolymorphismConsoleDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int square = 5;
            int[] rectangle = { 10, 5 };
            int[] box = { 10, 5, 2 };
            double areaSquare = polygon(square);
            double areaRectangle = polygon(rectangle);
            double volumeBox = polygon(box);
            Console.WriteLine("Area of square is " + areaSquare);
            Console.WriteLine("Area of rectangle is " + areaRectangle);
            Console.WriteLine("Volume of box is " + volumeBox);
            Console.ReadKey(); //to prevent the console from closing immediately
        }
        private static double polygon(params int[] dimensions)
        {
            int len = dimensions.Length;
            if(len == 1)
            {
                return dimensions[0] * dimensions[0];
            }
            if(len == 2)
            {
                return dimensions[0] * dimensions[1];
            }
            if(len == 3)
            {
                return dimensions[0] * dimensions[1] * dimensions[2];
            }
            return -1;
        }
    }
}
