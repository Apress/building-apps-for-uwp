﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Color_Architect.CustomCode;

namespace Color_Architect
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            colorFetch.IsChecked = true;
        }

        private void colorFetch_Checked(object sender, RoutedEventArgs e)
        {
            defaults.option = 1;
            setWindow();
            titleContent.Text = "Color Fetch";
            colorPick.IsChecked = false;
            colorMix.IsChecked = false;
            colorFetch.IsEnabled = false;
        }

        private void colorPick_Checked(object sender, RoutedEventArgs e)
        {
            defaults.option = 2;
            setWindow();
            titleContent.Text = "Color Pick";
            colorFetch.IsChecked = false;
            colorMix.IsChecked = false;
            colorPick.IsEnabled = false;
        }

        private void colorMix_Checked(object sender, RoutedEventArgs e)
        {
            defaults.option = 3;
            setWindow();
            titleContent.Text = "Color Mix";
            colorFetch.IsChecked = false;
            colorPick.IsChecked = false;
            colorMix.IsEnabled = false;
        }

        private void setWindow()
        {
            colorFetch.IsEnabled = true;
            colorPick.IsEnabled = true;
            colorMix.IsEnabled = true;
            switch (defaults.option)
            {
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    break;
                default:
                    break;
            }
        }
    }
}