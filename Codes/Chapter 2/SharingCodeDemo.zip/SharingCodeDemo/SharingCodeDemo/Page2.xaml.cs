﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using SharingCodeDemo.sharedArea;
namespace SharingCodeDemo
{
    public sealed partial class Page2 : Page
    {
        public Page2()
        {
            this.InitializeComponent();
        }
        private void box_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                string w = width.Text;
                string h = height.Text;
                string d = depth.Text;
                if(w.Length >= 1 && h.Length >=1 && d.Length >= 1)
                {
                    int width = Convert.ToInt32(w);
                    int height = Convert.ToInt32(h);
                    int depth = Convert.ToInt32(d);
                    double volume = sharedFunction.polygon(width, height, depth);
                    polygonVolume.Text = "Volume of Box = " + volume.ToString();
                }
            }
            catch
            {
                polygonVolume.Text = "Please check the inputs provided";
            }
        }

        private void areaPageButton_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage), null);
        }
    }
}
