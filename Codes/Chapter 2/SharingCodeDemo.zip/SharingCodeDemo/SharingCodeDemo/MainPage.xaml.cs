﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using SharingCodeDemo.sharedArea;
namespace SharingCodeDemo
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void squareSide_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                string sideS = squareSide.Text;
                if(sideS.Length >= 1)
                {
                    int side = Convert.ToInt32(sideS);
                    double area = sharedFunction.polygon(side);
                    polygonArea.Text = "Area of Square = " + area.ToString();
                }
            }
            catch
            {
                polygonArea.Text = "Side of a square must be a numberical value";
            }
        }

        private void rectangle_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                string rectS1 = rectangleSide1.Text;
                string rectS2 = rectangleSide2.Text;
                if (rectS1.Length >= 1 && rectS2.Length >= 1)
                {
                    int side1 = Convert.ToInt32(rectS1);
                    int side2 = Convert.ToInt32(rectS2);
                    double area = sharedFunction.polygon(side1, side2);
                    polygonArea.Text = "Area of Rectangle = " + area.ToString();
                }
            }
            catch
            {
                polygonArea.Text = "Sides of a rectangle must be numberical value";
            }
        }

        private void volumePageButton_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Page2), null);
        }
    }
}
