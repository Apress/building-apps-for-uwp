﻿namespace SharingCodeDemo.sharedArea
{
    class sharedFunction
    {
        public static double polygon(params int[] dimentions)
        {
            int len = dimentions.Length;
            return len == 1 ? dimentions[0] * dimentions[0] : len == 2 ? dimentions[0] * dimentions[1] : len == 3 ? dimentions[0] * dimentions[1] * dimentions[2] : -1;
        }
    }
}
