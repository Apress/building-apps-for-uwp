﻿using System;
using System.Collections.Generic;
using System.Linq;
using Windows.UI.Input;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;

namespace GestureDemo
{

    public sealed partial class MainPage : Page
    {
        List<double> x = new List<double>();
        List<double> y = new List<double>();

        public MainPage()
        {
            this.InitializeComponent();
        }

        private void tapButton_Tapped(object sender, TappedRoutedEventArgs e)
        {
            tapAction.Text = "Single Tap";
        }

        private void tapButton_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
        {
            tapAction.Text = "Double Tapped";
        }

        private void tapButton_RightTapped(object sender, RightTappedRoutedEventArgs e)
        {
            tapAction.Text = "Right Tapped";
        }

        private void tapButton_Holding(object sender, HoldingRoutedEventArgs e)
        {
            tapAction.Text = "Holding Event Triggered";
        }

        private void customGestureButton_ManipulationDelta(object sender, ManipulationDeltaRoutedEventArgs e)
        {
            x.Add(e.Position.X);
            y.Add(e.Position.Y);
        }

        private void customGestureButton_ManipulationCompleted(object sender, ManipulationCompletedRoutedEventArgs e)
        {
            //Converting lists to array
            double[] allX = x.ToArray();
            double[] allY = y.ToArray();
            int length = x.Count;
            double distance = 0;
            for(int i = 2; i<length; i++)
            {
                distance += Math.Sqrt((Math.Pow(allX[i-1] - allX[i], 2) + Math.Pow(allY[i-1] - allY[i], 2)));
            }
            tapAction.Text = "Distance travelled is " + distance;

            //Clear All data to start a fresh gesture
            x.Clear();
            y.Clear();
        }
    }
}
