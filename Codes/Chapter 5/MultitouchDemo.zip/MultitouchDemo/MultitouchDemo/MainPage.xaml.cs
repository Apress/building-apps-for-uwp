﻿using System;
using System.Collections.Generic;
using Windows.UI.Input;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;

namespace MultitouchDemo
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void touchCanvas_PointerMoved(object sender, PointerRoutedEventArgs e)
        {
            IList<PointerPoint> p = e.GetIntermediatePoints(touchCanvas);
            int count = p.Count;
            double sumX = 0, sumY = 0, maxX = 0, maxY = 0;
            if(count >= 2)
            {
                for (int i = 0; i < count; i++)
                {
                    PointerPoint current = p[i];
                    sumX += current.Position.X;
                    sumY += current.Position.Y;
                    maxX = maxX < current.Position.X ? current.Position.X : maxX;
                    maxY = maxY < current.Position.Y ? current.Position.Y : maxY;
                }
                double avgX = sumX / count;
                double avgY = sumY / count;
                byte R = Convert.ToByte(avgX * 255 / touchCanvas.ActualWidth);
                byte G = Convert.ToByte(avgY * 255 / touchCanvas.ActualHeight);
                byte B = Convert.ToByte(Math.Sqrt(Math.Pow(maxX, 2) + Math.Pow(maxY, 2)) / Math.Sqrt(Math.Pow(touchCanvas.ActualWidth, 2) + Math.Pow(touchCanvas.ActualHeight, 2)));
                touchColor.Fill = new SolidColorBrush(Windows.UI.Color.FromArgb(255, R, G, B));

                title.Text = count.ToString() + " pointers";
            }
        }
    }
}
