﻿using System;
using Windows.Storage.Streams;
using Windows.UI.Xaml.Controls;
using Windows.Security.Cryptography;
using Windows.Security.Cryptography.DataProtection;

namespace SecureAppDataDemo
{
    public sealed partial class MainPage : Page
    {
        string text;
        bool encrypt = true;
        IBuffer protectedData;
        public MainPage()
        {
            this.InitializeComponent();
        }
        private void plainTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            text = plainTextBox.Text;
            secureButton.IsEnabled = (text != null || text != "") ? true : false;
        }
        private async void secureButton_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            if (encrypt)
            {
                BinaryStringEncoding encoding = BinaryStringEncoding.Utf8;
                DataProtectionProvider provider = new DataProtectionProvider("LOCAL=user");
                IBuffer message = CryptographicBuffer.ConvertStringToBinary(text, encoding);
                protectedData = await provider.ProtectAsync(message);
                plainTextBox.Text = "Protected data has " + protectedData.Length + " bytes";
                secureButton.Content = "Decrypt";
                plainTextBox.IsEnabled = false;
                encrypt = false;
            }
            else
            {
                BinaryStringEncoding encoding = BinaryStringEncoding.Utf8;
                DataProtectionProvider Provider = new DataProtectionProvider("LOCAL=user");
                IBuffer unprotectedData = await Provider.UnprotectAsync(protectedData);
                plainTextBox.Text = CryptographicBuffer.ConvertBinaryToString(encoding, unprotectedData);
                secureButton.Content = "Encrypt";
                plainTextBox.IsEnabled = true;
                encrypt = true;
            }
        }
    }
}
