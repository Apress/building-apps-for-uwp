﻿using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
namespace CustomControlsDemo.CustomControls
{
    public sealed class BlueButton : Control
    {
        public BlueButton()
        {
            this.DefaultStyleKey = typeof(BlueButton);
        }
        public string BlueButtonText
        {
            get { return (string)GetValue(BlueButtonTextProperty); }
            set { SetValue(BlueButtonTextProperty, value); }
        }
        public static readonly DependencyProperty BlueButtonTextProperty =
            DependencyProperty.Register("BlueButtonText", typeof(string), typeof(BlueButton), new PropertyMetadata(""));
    }
}
