﻿using Windows.UI.Xaml.Controls;
namespace StatesDemo
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
    }
}
