﻿using Windows.UI.Input;
using Windows.UI.Xaml.Controls;

namespace SurfaceDialDemo
{
    public sealed partial class MainPage : Page
    {
        RadialController myController;
        public MainPage()
        {
            this.InitializeComponent();
            if (RadialController.IsSupported()) //to check if it is supported on the machine
            {
                myController = RadialController.CreateForCurrentView();
                RadialControllerMenuItem newItem = RadialControllerMenuItem.CreateFromKnownIcon("Ink Color", RadialControllerMenuKnownIcon.InkColor);
                myController.Menu.Items.Add(newItem);
                myController.ButtonClicked += MyController_ButtonClicked;
                myController.RotationChanged += MyController_RotationChanged;
            }
        }

        private void MyController_RotationChanged(RadialController sender, RadialControllerRotationChangedEventArgs args)
        {
            double rotation = myController.RotationResolutionInDegrees;
            //Implement your code
        }

        private void MyController_ButtonClicked(RadialController sender, RadialControllerButtonClickedEventArgs args)
        {
            //Implement your code
        }
    }
}
