﻿
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace unitTestAddition
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void testingAddition()
        {
            double test1Result = UnitTestingDemo.MainPage.addNumbers(-3, 2);
            Assert.AreEqual(-1, test1Result);
        }
    }
}
