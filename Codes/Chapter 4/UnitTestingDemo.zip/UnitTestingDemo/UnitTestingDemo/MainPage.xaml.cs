﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
namespace UnitTestingDemo
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
        private void computeButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double n1 = Convert.ToDouble(num1.Text);
                double n2 = Convert.ToDouble(num2.Text);
                result.Text = addNumbers(n1, n2).ToString();
            }
            catch { }
        }
        public static double addNumbers(double n1, double n2)
        {
            return n1 + n2;
        }
    }
}
