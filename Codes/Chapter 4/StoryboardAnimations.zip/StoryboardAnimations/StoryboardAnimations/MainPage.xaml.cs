﻿using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace StoryboardAnimations
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            storyboardDemo.Begin(); //to start the storyboard animation
        }
        protected override void OnNavigatingFrom(NavigatingCancelEventArgs e)
        {
            storyboardDemo.Stop(); //to stop the animation
        }
    }
}
