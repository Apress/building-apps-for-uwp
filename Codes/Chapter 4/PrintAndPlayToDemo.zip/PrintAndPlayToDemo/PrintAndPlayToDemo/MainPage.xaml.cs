﻿using System;
using Windows.Graphics.Printing;
using Windows.Media.Casting;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml.Printing;
namespace PrintAndPlayToDemo
{
    public sealed partial class MainPage : Page
    {
        private PrintDocument printDoc;
        private PrintManager printMan;
        private IPrintDocumentSource printDocSource;
        public MainPage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            printMan = PrintManager.GetForCurrentView();
            printMan.PrintTaskRequested += PrintMan_PrintTaskRequested;
            printDoc = new PrintDocument();
            printDocSource = printDoc.DocumentSource;
            printDoc.Paginate += PrintDoc_Paginate;
            printDoc.GetPreviewPage += PrintDoc_GetPreviewPage;
            printDoc.AddPages += PrintDoc_AddPages;
        }
        //Printing
        private void PrintDoc_Paginate(object sender, PaginateEventArgs e)
        {
            printDoc.SetPreviewPageCount(1, PreviewPageCountType.Final);
        }
        private void PrintDoc_AddPages(object sender, AddPagesEventArgs e)
        {
            printDoc.AddPage(myPhoto);
            printDoc.AddPagesComplete();
        }
        private void PrintDoc_GetPreviewPage(object sender, GetPreviewPageEventArgs e)
        {
            printDoc.SetPreviewPage(e.PageNumber, myPhoto);
        }
        private void PrintMan_PrintTaskRequested(PrintManager sender, PrintTaskRequestedEventArgs args)
        {
            var printTask = args.Request.CreatePrintTask("Print", PrintTaskSourceRequested);
            printTask.Completed += PrintTask_Completed;
        }
        private void PrintTaskSourceRequested(PrintTaskSourceRequestedArgs args)
        {
            args.SetSource(printDocSource);
        }
        private void PrintTask_Completed(PrintTask sender, PrintTaskCompletedEventArgs args)
        {
            //Notify user that printing has completed
        }
        private async void printImage_Click(object sender, RoutedEventArgs e)
        {
            if (PrintManager.IsSupported())
            {
                await PrintManager.ShowPrintUIAsync();
            }
        }
        //Casting
        CastingDevicePicker castingPicker;
        private void streamImage_Click(object sender, RoutedEventArgs e)
        {
            castingPicker = new CastingDevicePicker();
            castingPicker.Filter.SupportsPictures = true;
            if(castingPicker.Filter.SupportedCastingSources.Count == 0)
            {
                //no devices supported
            }
            castingPicker.CastingDeviceSelected += CastingPicker_CastingDeviceSelected;
        }
        private async void CastingPicker_CastingDeviceSelected(CastingDevicePicker sender, CastingDeviceSelectedEventArgs args)
        {
            await Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, async () =>
            {
                CastingConnection connection = args.SelectedCastingDevice.CreateCastingConnection();
                connection.ErrorOccurred += Connection_ErrorOccurred; ;
                connection.StateChanged += Connection_StateChanged; ;
                await connection.RequestStartCastingAsync(myPhoto.GetAsCastingSource());
            });
        }
        private void Connection_StateChanged(CastingConnection sender, object args)
        {
            throw new NotImplementedException();
        }
        private void Connection_ErrorOccurred(CastingConnection sender, CastingConnectionErrorOccurredEventArgs args)
        {
            throw new NotImplementedException();
        }
    }
}
