﻿using Windows.UI.Xaml.Controls;
using InterfaceDemo.CustomStuff;
using System.Diagnostics;
namespace InterfaceDemo
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            Definitions mat1 = new Definitions();
            Debug.WriteLine(mat1.GetMaterialType(materials.Ice).ToString());
            Debug.WriteLine(mat1.GetMaterialType(materials.Water).ToString());
        }
    }
}
