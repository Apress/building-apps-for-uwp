﻿using Windows.UI;
using Windows.UI.Xaml.Media;
namespace InterfaceDemo.CustomStuff
{
    public enum materials
    {
        Iron,
        Ceramic,
        Grass,
        Tree,
        Ice,
        Water,
        Mud,
        Aluminium
    }
    public enum materialType
    {
        solid,
        liquid,
        gas
    }
    class Definitions : IMaterial
    {
        public SolidColorBrush GetMaterialColor(materials material)
        {
            return new SolidColorBrush(Color.FromArgb(255, 165, 210, 100)); //dummy color used
        }

        public double GetMaterialReflectance(materials material, double wavelength)
        {
            return 0.9; //dummy reflectance used
        }

        public materialType GetMaterialType(materials material)
        {
            switch (material)
            {
                case materials.Aluminium: //taking advantage of fall down property
                case materials.Ceramic:
                case materials.Grass:
                case materials.Ice:
                case materials.Iron:
                case materials.Tree: return materialType.solid;
                case materials.Water: return materialType.liquid;
            }
            return materialType.gas;
        }
    }
}
