﻿using Windows.UI.Xaml.Media;
namespace InterfaceDemo.CustomStuff
{
    interface IMaterial
    {
        double GetMaterialReflectance(materials material, double wavelength);
        materialType GetMaterialType(materials material);
        SolidColorBrush GetMaterialColor(materials material);
    }
}
