﻿using System;
using Windows.Devices.Enumeration;
using Windows.Media.Capture;
using Windows.Storage;
using Windows.UI.Xaml.Controls;
namespace CameraDemo
{
    public sealed partial class MainPage : Page
    {
        int elem = -1;
        DeviceInformationCollection devices;
        MediaCapture mc = new MediaCapture();
        public MainPage()
        {
            this.InitializeComponent();
            initializeCamera();
        }

        private async void initializeCamera()
        {
            devices = await DeviceInformation.FindAllAsync(DeviceClass.VideoCapture);
            if(devices.Count > 1)
            {
                switchCameraButton.Visibility = Windows.UI.Xaml.Visibility.Visible;
            }
            if(devices.Count > 0)
            {
                elem = 0;
                MediaCaptureInitializationSettings mcSettings = new MediaCaptureInitializationSettings { VideoDeviceId = devices[elem].Id, StreamingCaptureMode = StreamingCaptureMode.Video};
                await mc.InitializeAsync(mcSettings);
                captureElement.Source = mc;
                await mc.StartPreviewAsync();
            }
        }
        private async void photocaptureButton_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            await mc.StopPreviewAsync();
            CameraCaptureUI camera = new CameraCaptureUI();
            camera.PhotoSettings.Format = CameraCaptureUIPhotoFormat.Jpeg;
            StorageFile photo = await camera.CaptureFileAsync(CameraCaptureUIMode.Photo);
            if(photo != null)
                await photo.MoveAsync(KnownFolders.PicturesLibrary, "new_photo.jpeg", NameCollisionOption.GenerateUniqueName);
            await mc.StartPreviewAsync();
        }
        private async void videoCaptureButton_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            await mc.StopPreviewAsync();
            CameraCaptureUI camera = new CameraCaptureUI();
            camera.VideoSettings.Format = CameraCaptureUIVideoFormat.Mp4;
            StorageFile video = await camera.CaptureFileAsync(CameraCaptureUIMode.Video);
            if (video != null)
                await video.MoveAsync(KnownFolders.VideosLibrary, "new_video.mp4", NameCollisionOption.GenerateUniqueName);
            await mc.StartPreviewAsync();
        }

        private async void switchCameraButton_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            await mc.StopPreviewAsync();
            mc.Dispose();
            MediaCapture mcNew = new MediaCapture();
            elem = elem < devices.Count - 1 ? elem + 1 : 0;
            MediaCaptureInitializationSettings mcSettings = new MediaCaptureInitializationSettings { VideoDeviceId = devices[elem].Id, StreamingCaptureMode = StreamingCaptureMode.Video };
            await mcNew.InitializeAsync(mcSettings);
            captureElement.Source = mcNew;
            await mcNew.StartPreviewAsync();
            mc = mcNew;
        }
    }
}
