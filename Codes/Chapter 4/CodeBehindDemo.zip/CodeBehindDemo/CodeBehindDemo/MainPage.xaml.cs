﻿using System.Collections.Generic;
using System.Diagnostics;
using Windows.UI.Xaml.Controls;
namespace CodeBehindDemo
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            people person1 = new people("Joey", month.February);
            people person2 = new people("Amanda", month.June);
            Debug.WriteLine(person1.name);
            Debug.WriteLine(person2.name);
        }
    }
    public enum month
    {
        January,
        February,
        March,
        April,
        May,
        June,
        July,
        August,
        Septeber,
        October,
        November,
        December
    }
    public struct people
    {
        public string name;
        public month birthMonth;
        public people(string n, month bm)
        {
            name = n;
            birthMonth = bm;
        }
    }
}
