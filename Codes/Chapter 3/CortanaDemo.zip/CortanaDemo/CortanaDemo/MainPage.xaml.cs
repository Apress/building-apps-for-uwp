﻿using Windows.UI.Xaml.Controls;

namespace CortanaDemo
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
    }
}
