﻿using System;
using Windows.ApplicationModel.Core;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
namespace MultipleViewDemo
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private async void page2Button_Click(object sender, RoutedEventArgs e)
        {
            CoreApplicationView page2View = CoreApplication.CreateNewView();
            int page2ViewID = 0;
            await page2View.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
            {
                Frame newFrame = new Frame();
                newFrame.Navigate(typeof(Page2), null);
                Window.Current.Content = newFrame;
                Window.Current.Activate();
                page2ViewID = ApplicationView.GetForCurrentView().Id;
            });
            await ApplicationViewSwitcher.TryShowAsStandaloneAsync(page2ViewID);
        }
    }
}
