﻿using Windows.UI.Xaml.Controls;

namespace NavigationDemo
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void navigateToPage2_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            Frame.Navigate(typeof(Page2));
        }
    }
}
