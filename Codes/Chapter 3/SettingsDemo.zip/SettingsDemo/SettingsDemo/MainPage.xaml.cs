﻿using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.Storage;
using Windows.UI.Xaml.Navigation;

namespace SettingsDemo
{
    public sealed partial class MainPage : Page
    {
        string name;
        ApplicationDataContainer local = ApplicationData.Current.LocalSettings;
        ApplicationDataContainer roaming = ApplicationData.Current.RoamingSettings;

        public MainPage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            var n = roaming.Values["name"];
            if (n != null)
            {
                name = n.ToString();
                nameText.Text = "Hi! " + name;
                textBox.Text = name;
            }
            var t = local.Values["theme"];
            if(t != null)
            {
                byte theme = System.Convert.ToByte(t.ToString());
                if(theme == 1)
                {
                    lightThemeRadio.IsChecked = true;
                    darkThemeRadio.IsChecked = false;
                    lightThemeRadio.IsEnabled = false;
                    darkThemeRadio.IsEnabled = true;
                    mainGrid.RequestedTheme = ElementTheme.Light;
                }
                else
                {
                    darkThemeRadio.IsChecked = true;
                    lightThemeRadio.IsChecked = false;
                    darkThemeRadio.IsEnabled = false;
                    lightThemeRadio.IsEnabled = true;
                    mainGrid.RequestedTheme = ElementTheme.Dark;
                }
            }
            else
            {
                darkThemeRadio.IsChecked = false;
                lightThemeRadio.IsEnabled = false;
                darkThemeRadio.IsEnabled = true;
                mainGrid.RequestedTheme = ElementTheme.Light;
            }
        }

        private void settingsButton_Click(object sender, RoutedEventArgs e)
        {
            settingsGrid.Visibility = Visibility.Visible;
        }

        private void lightThemeRadio_Checked(object sender, RoutedEventArgs e)
        {
            darkThemeRadio.IsChecked = false;
            lightThemeRadio.IsEnabled = false;
            darkThemeRadio.IsEnabled = true;
            mainGrid.RequestedTheme = ElementTheme.Light;
            local.Values["theme"] = 1;
        }

        private void darkThemeRadio_Checked(object sender, RoutedEventArgs e)
        {
            lightThemeRadio.IsChecked = false;
            darkThemeRadio.IsEnabled = false;
            lightThemeRadio.IsEnabled = true;
            mainGrid.RequestedTheme = ElementTheme.Dark;
            local.Values["theme"] = 2;
        }

        private void settingsDoneButton_Click(object sender, RoutedEventArgs e)
        {
            settingsGrid.Visibility = Visibility.Collapsed;
            nameText.Text = "Hi! " + name;
            roaming.Values["name"] = name;
        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            name = textBox.Text;
        }
    }
}
