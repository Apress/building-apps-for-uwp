﻿using Windows.ApplicationModel.DataTransfer;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace ShareDemo
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if(textBox.Text == "")
            {
                shareButton.IsEnabled = false;
            }
            else
            {
                shareButton.IsEnabled = true;
            }
        }

        private void shareButton_Click(object sender, RoutedEventArgs e)
        {
            DataTransferManager manager = DataTransferManager.GetForCurrentView();
            manager.DataRequested += Manager_DataRequested;
            DataTransferManager.ShowShareUI();
        }

        private void Manager_DataRequested(DataTransferManager sender, DataRequestedEventArgs args)
        {
            DataRequest data = args.Request;
            data.Data.SetText(textBox.Text);
            data.Data.Properties.Title = "ShareDemo Text";
        }
    }
}
