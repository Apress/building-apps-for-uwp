﻿using Windows.UI.Xaml.Controls;
using Windows.Devices.Gpio;
namespace IoTExample
{
    public sealed partial class MainPage : Page
    {
        GpioPin myPin;
        public MainPage()
        {
            this.InitializeComponent();
            var myGpio = GpioController.GetDefault();
            if(myGpio != null)
            {
                //do something with your GPIO
            }
        }
    }
}
