﻿using System;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
namespace MultithreadingDemo
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
        private static int[] numbers;
        private void runButton_Click(object sender, RoutedEventArgs e)
        {
            int n = Convert.ToInt32(totNums.Text);
            numbers = new int[n];
            Random rand = new Random();
            for (int i = 0; i < n; i++)
            {
                numbers[i] = rand.Next(1, 100); //Generates random integer between 1 and 100
            }
            DateTime timer = DateTime.UtcNow;
            for (int i = 0; i < n; i++)
            {
                numbers[i] = 2 * numbers[i] + 3;
                numbers[i] = Convert.ToInt32((numbers[i] - 3) / 2);
            }
            DateTime finished = DateTime.Now;
            TimeSpan timeTaken = finished - timer;

            forText.Text = "For loop took " + timeTaken.Milliseconds + " milliseconds.";

            ////Recreates the previous state of numbers array
            numbers = new int[n];
            for (int i = 0; i < n; i++)
            {
                numbers[i] = rand.Next(1, 100); //Generates random integer between 1 and 100
            }

            timer = DateTime.UtcNow;
            Parallel.For(0, n, i => {
                numbers[i] = 2 * numbers[i] + 3;
                numbers[i] = Convert.ToInt32((numbers[i] - 3) / 2);
            });
            finished = DateTime.Now;
            timeTaken = finished - timer;
            parforText.Text = "Parallel for loop took " + timeTaken.Milliseconds + " milliseconds.";
        }
    }
}
