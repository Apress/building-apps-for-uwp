﻿using System;
using Windows.System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;


namespace SkypeChatDemo
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private async void skypeCallButton_Click(object sender, RoutedEventArgs e)
        {
            if(skypeName.Text != "")
            {
                await Launcher.LaunchUriAsync(new Uri("skype:" + skypeName.Text + "?call"));
            }
        }

        private async void skypeMessageButton_Click(object sender, RoutedEventArgs e)
        {
            if (skypeName.Text != "")
            {
                await Launcher.LaunchUriAsync(new Uri("skype:" + skypeName.Text + "?chat"));
            }
        }
    }
}
