﻿using System;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;
namespace AppToAppCommunicationDemo
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private async void sharedImage_Drop(object sender, DragEventArgs e)
        {
            var img = await e.DataView.GetStorageItemsAsync();
            StorageFile imgFile = img[0] as StorageFile;
            BitmapImage i = new BitmapImage();
            i.SetSource(await imgFile.OpenAsync(FileAccessMode.Read));
            sharedImage.Source = i;
        }

        private void clipboardCopy_Click(object sender, RoutedEventArgs e)
        {
            if(someText.Text.Length > 1)
            {
                DataPackage dataPackage = new DataPackage();
                dataPackage.RequestedOperation = DataPackageOperation.Copy;
                dataPackage.SetText(someText.Text);
                Clipboard.SetContent(dataPackage);
            }
        }
        private void sharedImage_DragOver(object sender, DragEventArgs e)
        {
            e.AcceptedOperation = DataPackageOperation.Copy;
        }
    }
}
