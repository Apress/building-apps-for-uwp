﻿using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
namespace AsynchronousOperationDemo
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
        private async void task1_Click(object sender, RoutedEventArgs e)
        {
            result1.Text = "";
            result1.Text = await performTask1();
        }
        private async void task2_Click(object sender, RoutedEventArgs e)
        {
            result2.Text = "";
            result2.Text = await performTask2();
        }
        private async Task<string> performTask1()
        {
            await Task.Delay(1000);
            return "Task 1 Completed";
        }
        private async Task<string> performTask2()
        {
            await Task.Delay(500);
            return "Task 2 Completed";
        }
    }
}
