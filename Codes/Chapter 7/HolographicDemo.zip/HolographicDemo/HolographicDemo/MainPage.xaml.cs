﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace HolographicDemo
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private Boolean rectangleRotating { get; set; } = false;

        private void rotateRectangleButton_Click(object sender, RoutedEventArgs e)
        {
            if (rectangleRotating)
            {
                RotateRectangle.Stop();
                rotateRectangleButton.Label = "Rotate Again";
                rectangleRotating = false;
            }
            else
            {
                RotateRectangle.Begin();
                rotateRectangleButton.Label = "Stop Rotation";
                rectangleRotating = true;
            }
        }
    }
}
