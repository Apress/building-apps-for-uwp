﻿using System;
using UIKit;

namespace iOSDemo
{
    public partial class ViewController : UIViewController
    {
        byte r = 127, g = 127, b = 127;
        public ViewController(IntPtr handle) : base(handle)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            updateViewColor();
            RedSlider.ValueChanged += RedSlider_ValueChanged;
            BlueSlider.ValueChanged += BlueSlider_ValueChanged;
            GreenSlider.ValueChanged += GreenSlider_ValueChanged;
        }

        private void GreenSlider_ValueChanged(object sender, EventArgs e)
        {
            g = Convert.ToByte(GreenSlider.Value);
        }

        private void BlueSlider_ValueChanged(object sender, EventArgs e)
        {
            b = Convert.ToByte(BlueSlider.Value);
        }

        private void RedSlider_ValueChanged(object sender, EventArgs e)
        {
            r = Convert.ToByte(RedSlider.Value);
            updateViewColor();
        }

        private void updateViewColor()
        {
            ColorChangeView.BackgroundColor = new UIColor(red: r / 255, green: g / 255, blue: b / 255, alpha: 1);
        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
            // Release any cached data, images, etc that aren't in use.
        }
    }
}