using System;
using System.Threading.Tasks;
using Xamarin.Forms;
using System.Collections.Generic;

namespace CrossPlatformDemo.Droid.Helpers
{
    //This class is a placeholder for implementing Social Authentication
    public class SocialAuthentication
    {
    }
}
