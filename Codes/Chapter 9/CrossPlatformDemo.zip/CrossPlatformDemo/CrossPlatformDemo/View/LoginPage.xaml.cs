﻿
using Xamarin.Forms;

namespace CrossPlatformDemo.View
{
    public partial class LoginPage : ContentPage
    {
        public LoginPage()
        {
            InitializeComponent();

        }
    }
}
