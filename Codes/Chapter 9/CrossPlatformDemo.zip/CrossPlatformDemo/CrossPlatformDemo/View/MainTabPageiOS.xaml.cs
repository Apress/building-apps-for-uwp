﻿
using Xamarin.Forms;

namespace CrossPlatformDemo.View
{
    public partial class MainTabPageiOS : TabbedPage
    {
        public MainTabPageiOS()
        {
            InitializeComponent();
        }
    }
}
