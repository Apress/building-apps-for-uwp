﻿
using Xamarin.Forms;

namespace CrossPlatformDemo.View
{
    public partial class MainTabPage : TabbedPage
    {
        public MainTabPage()
        {
            InitializeComponent();
        }
    }
}
