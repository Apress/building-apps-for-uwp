﻿using CrossPlatformDemo.Model;

namespace CrossPlatformDemo.Interfaces
{
    public interface IMyItemStore : IBaseStore<MyItem>
    {
        //Add additional interface methods
        //specific to this data store.
    }
}
