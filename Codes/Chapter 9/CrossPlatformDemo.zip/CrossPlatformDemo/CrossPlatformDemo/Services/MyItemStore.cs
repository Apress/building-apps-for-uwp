﻿using CrossPlatformDemo.Interfaces;
using CrossPlatformDemo.Model;
using CrossPlatformDemo.Services.Standard;
using Xamarin.Forms;

[assembly: Dependency(typeof(MyItemStore))]
namespace CrossPlatformDemo.Services.Standard
{
    public class MyItemStore : BaseStore<MyItem>, IMyItemStore
    {
        public override string Identifier => "MyItem";
    }
}
