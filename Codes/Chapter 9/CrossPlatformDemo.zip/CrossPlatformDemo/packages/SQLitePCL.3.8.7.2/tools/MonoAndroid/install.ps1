param($installPath, $toolsPath, $package, $project)

Write-Host "SQLite is natively supported on Android."