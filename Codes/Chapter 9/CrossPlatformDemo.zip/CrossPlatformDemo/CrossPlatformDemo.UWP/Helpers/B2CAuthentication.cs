﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CrossPlatformDemo.UWP.Helpers;
using Xamarin.Forms;

namespace CrossPlatformDemo.UWP.Helpers
{
    //This class is a placeholder for implementing B2C Authentication
    public class B2CAuthentication
    {
    }
}
