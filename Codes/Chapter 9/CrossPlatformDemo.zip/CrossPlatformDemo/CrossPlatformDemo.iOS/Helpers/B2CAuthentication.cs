﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CrossPlatformDemo.iOS.Helpers;
using Xamarin.Forms;

namespace CrossPlatformDemo.iOS.Helpers
{
    //This class is a placeholder for implementing B2C Authentication
    public class B2CAuthentication
    {
    }
}
